package com.example.cherie.ohrapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioButton;

public class LijstRedenenPos extends AppCompatActivity {

    private Button NextLRP;
    private Button OtherLRP;
    private Button PreviousLRP;

    private RadioGroup ReasonGroupPos;
    private RadioButton radioReasonPos1, radioReasonPos2, radioReasonPos3, radioReasonPos4, radioReasonPos5;
    private String strReasonsPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lijst_redenen_pos);

        ReasonGroupPos = (RadioGroup)findViewById(R.id.ReasonGroupPos);

        NextLRP = (Button)findViewById(R.id.btnNextRedPos);
        OtherLRP = (Button)findViewById(R.id.btnOthRedPos);
        PreviousLRP = (Button)findViewById(R.id.btnPrevRedPos);

        // Select reasons
        ReasonGroupPos.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioReasonPos1) {
                    strReasonsPos = "1";
                }
                else if (checkedId == R.id.radioReasonPos2) {
                    strReasonsPos = "2";
                }
                else  if (checkedId == R.id.radioReasonPos3) {
                    strReasonsPos = "3";
                }
                else  if (checkedId == R.id.radioReasonPos4) {
                    strReasonsPos = "4";
                }
                else  if (checkedId == R.id.radioReasonPos5) {
                    strReasonsPos = "5";
                }

            }
        });

        // Navigation

        NextLRP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Verzonden.class);
                startActivity(intent);
            }
        });

        OtherLRP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AndereRedenPos.class);
                startActivity(intent);
            }
        });

        PreviousLRP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LesGoedSlecht.class);
                startActivity(intent);
            }
        });
    }
}
