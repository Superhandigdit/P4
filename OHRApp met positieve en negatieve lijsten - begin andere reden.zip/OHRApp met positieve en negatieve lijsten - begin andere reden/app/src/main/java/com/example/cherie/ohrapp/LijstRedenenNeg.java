package com.example.cherie.ohrapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.RadioButton;

public class LijstRedenenNeg extends AppCompatActivity {

    private Button NextLRN;
    private Button OtherLRN;
    private Button PreviousLRN;

    private RadioGroup ReasonGroupNeg;
    private RadioButton radioReasonNeg1, radioReasonNeg2, radioReasonNeg3, radioReasonNeg4, radioReasonNeg5;
    private String strReasonsNeg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lijst_redenen_neg);

        ReasonGroupNeg = (RadioGroup)findViewById(R.id.ReasonGroupNeg);

        NextLRN = (Button)findViewById(R.id.btnNextRedNeg);
        OtherLRN = (Button)findViewById(R.id.btnOthRedNeg);
        PreviousLRN = (Button)findViewById(R.id.btnPrevRedNeg);

        // Select reasons
        ReasonGroupNeg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioReasonNeg1) {
                    strReasonsNeg = "1";
                }
                else if (checkedId == R.id.radioReasonNeg2) {
                    strReasonsNeg = "2";
                }
                else  if (checkedId == R.id.radioReasonNeg3) {
                    strReasonsNeg = "3";
                }
                else  if (checkedId == R.id.radioReasonNeg4) {
                    strReasonsNeg = "4";
                }
                else  if (checkedId == R.id.radioReasonNeg5) {
                    strReasonsNeg = "5";
                }

            }
        });

        // Navigation

        NextLRN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Verzonden.class);
                startActivity(intent);
            }
        });

        OtherLRN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AndereRedenNeg.class);
                startActivity(intent);
            }
        });

        PreviousLRN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LesGoedSlecht.class);
                startActivity(intent);
            }
        });
    }
}
